package stickman.model.Strategy;

public class NonMushroomed implements HeroAttackStratgy{
    @Override
    public boolean attack() {
        return false;
    }


}
