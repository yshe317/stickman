package stickman.model.Strategy;

public class Mushroomed implements HeroAttackStratgy{
    @Override
    public boolean attack() {
        return true;
    }
}
