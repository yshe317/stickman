package stickman.model.Strategy;

public interface HeroAttackStratgy {
    boolean attack();
}
