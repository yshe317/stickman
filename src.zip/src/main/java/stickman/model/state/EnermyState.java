package stickman.model.state;

import stickman.model.entity.MovableEntity;

public interface EnermyState {
    public void think();
    public String getImagePath();

}


